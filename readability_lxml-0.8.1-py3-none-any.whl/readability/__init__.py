__version__ = "0.8.1"

from .readability import Document
